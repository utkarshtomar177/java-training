Place the "test" folder inside c drive "C:/" 
Or
CSV and Txt file should be inside "C:/test/" 

Commands to execute the program:
- maven package
-j ava -cp target/my-app-1.0-SNAPSHOT.jar com.mycompany.app.App